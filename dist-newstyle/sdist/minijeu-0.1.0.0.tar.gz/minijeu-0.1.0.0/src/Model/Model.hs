module Model.Model where

import SDL
import qualified Debug.Trace as Debug (trace)
import qualified Data.Map as M
import Model.Ville as V
import Model.Shapes
import Data.IORef
import System.IO.Unsafe (unsafePerformIO)
import Data.Time.Clock (UTCTime, getCurrentTime, addUTCTime)

-- Global counter for generating unique citizen IDs
{-# NOINLINE citizenCounter #-}
citizenCounter :: IORef Int
citizenCounter = unsafePerformIO (newIORef 0)

data BuildType = BuildZone Zone | BuildBatiment Batiment ZonId deriving Show

data Message = Message
  { msgText :: String
  , msgEndTime :: UTCTime
  }

data GameState = GameState
  { ville :: V.Ville
  , money :: Integer  
  , buildMode :: BuildMode
  , selectedBuild :: Maybe BuildType
  , message :: Maybe Message  -- Ajouter un champ pour le message
  }

data BuildMode = Build | Move | Destroy deriving Show

-- Initial game state
initGameState :: GameState
initGameState = GameState
  { ville = V.Ville M.empty M.empty
  , money = 1000  -- Starting money, adjust as needed
  , buildMode = Build
  , selectedBuild = Nothing
  , message = Nothing
  }

-- Generate unique citizen ID
generateUniqueCitizenId :: IO CitId
generateUniqueCitizenId = do
  currentCount <- readIORef citizenCounter
  let newCount = currentCount + 1
  writeIORef citizenCounter newCount
  return $ CitId ("citizen" ++ show newCount)

-- Function to modify money, e.g., add money
addMoney :: Integer -> GameState -> GameState
addMoney amount game = game { money = money game + amount }

-- Similarly for spending money
spendMoney :: Integer -> GameState -> GameState
spendMoney amount game
  | amount > money game = error "Not enough money"
  | otherwise = game { money = money game - amount }

printMoney :: GameState -> IO ()
printMoney game = putStrLn $ "Current money: " ++ show (money game)

-- Function to get the cost of a build type
buildCost :: BuildType -> Integer
buildCost (BuildZone (ZR _ _)) = 100
buildCost (BuildZone (ZC _ _)) = 100
buildCost (BuildZone (ZI _ _)) = 100
buildCost (BuildZone (Route _)) = 10
buildCost (BuildZone (Eau _)) = 10
buildCost (BuildBatiment _ _) = 50 -- Example cost for buildings, adjust as needed
buildCost _ = 0

-- Fonction auxiliaire pour ajouter des citoyens à l'état du jeu
addCitizensToState :: GameState -> [Citoyen] -> GameState
addCitizensToState gameState newCitizens =
  gameState { ville = (ville gameState) { viCit = M.union (viCit (ville gameState)) (M.fromList $ map (\c -> (V.getCitId c, c)) newCitizens) } }

-- Generate citizens for a house
generateCitizensForHouse :: Coord -> Int -> IO [CitId]
generateCitizensForHouse coord capacity = do
  let message = "Generating citizens for house at " ++ show coord ++ " with capacity " ++ show capacity
  Debug.trace message (mapM (\_ -> generateUniqueCitizenId) [1..capacity])

-- La fonction `applyBuild` reste inchangée
applyBuild :: GameState -> BuildType -> Coord -> Int -> Int -> IO (Maybe GameState)
applyBuild gameState buildType coord width height = do
  currentTime <- getCurrentTime
  let cost = buildCost buildType
      newMessage text = Just (Message text (addUTCTime 1 currentTime))
      currentVille = ville gameState
      maybeZonId = getZoneIdAtCoord currentVille coord

  if money gameState < cost
     then return $ Just gameState { message = newMessage "Not enough money" }
     else case buildType of
            BuildZone zone -> 
              let newZone = updateZoneCoord zone coord width height
                  newVille = V.construit currentVille newZone (V.nextZonId currentVille)
              in if V.prop_ville_sansCollision newVille
                 then return $ Just gameState { ville = newVille, money = money gameState - cost, message = newMessage "Zone construite avec succès" }
                 else return $ Just gameState { message = newMessage ("Construction failed: Zone collision or adjacency issues with " ++ show newZone) }
            BuildBatiment batiment _ -> 
              case maybeZonId of
                Just zonId -> do
                  let updatedBatiment = updateBatimentCoord batiment coord width height
                  newCitizenIds <- generateCitizensForHouse coord 5  -- Changez 5 pour le nombre souhaité de citoyens
                  let _ = Debug.trace ("Generated Citizens: " ++ show newCitizenIds) ()  -- Trace for generated citizens
                      newCitizens = map (\cid -> createCitizen coord cid (getBatimentId updatedBatiment)) newCitizenIds
                      updatedVille = V.addBatiment updatedBatiment currentVille zonId
                      updatedVilleWithCitizens = updatedVille { viCit = M.union (viCit updatedVille) (M.fromList $ map (\c -> (getCitId c, c)) newCitizens) }
                      logBatiment = Debug.trace ("Updated Batiment: " ++ show updatedBatiment) updatedVilleWithCitizens
                      logCitizens = Debug.trace ("Updated Citizens: " ++ show (viCit updatedVilleWithCitizens)) logBatiment
                      logVille = Debug.trace ("Updated Ville: " ++ showVille updatedVilleWithCitizens) logCitizens
                  return $ Just gameState { ville = logVille, money = money gameState - cost, message = newMessage "Bâtiment construit avec succès" }
                Nothing -> return $ Just gameState { message = newMessage "No suitable zone found" }

-- Helper functions to update coordinates
updateZoneCoord :: Zone -> Coord -> Int -> Int -> Zone
updateZoneCoord (ZR _ bs) coord w h = ZR (RectangleP coord w h) bs
updateZoneCoord (ZI _ bs) coord w h = ZI (RectangleP coord w h) bs
updateZoneCoord (ZC _ bs) coord w h = ZC (RectangleP coord w h) bs
updateZoneCoord (Route _) coord w h = Route (RectangleP coord w h)
updateZoneCoord (Eau _) coord w h = Eau (RectangleP coord w h)
updateZoneCoord (Admin _ b) coord w h = Admin (RectangleP coord w h) b

updateBatimentCoord :: Batiment -> Coord -> Int -> Int -> Batiment
updateBatimentCoord (Cabane _ _ zid bid cids) coord w h = Cabane (RectangleP coord w h) coord zid bid cids
updateBatimentCoord (Atelier _ _ zid bid cids) coord w h = Atelier (RectangleP coord w h) coord zid bid cids
updateBatimentCoord (Epicerie _ _ zid bid cids) coord w h = Epicerie (RectangleP coord w h) coord zid bid cids
updateBatimentCoord (Commissariat _ _ zid bid cids) coord w h = Commissariat (RectangleP coord w h) coord zid bid cids
updateBatimentCoord (Maison _ _ zid bid cids) coord w h = Maison (RectangleP coord w h) coord zid bid cids

-- Exemple de fonction pour créer un nouvel habitant avec un état et une occupation de base
createCitizen :: Coord -> CitId -> BatId -> Citoyen
createCitizen coord cid batId = Habitant coord (100, 100, 100) (batId, Nothing, Nothing) Dormir cid

getZoneIdAtCoord :: Ville -> Coord -> Maybe ZonId
getZoneIdAtCoord ville coord =
  let zones = M.toList (viZones ville)
      matchingZones = filter (\(_, zone) -> isWithinZone coord zone) zones
  in case matchingZones of
       ((zid, _):_) -> Just zid
       [] -> Nothing

isWithinZone :: Coord -> Zone -> Bool
isWithinZone (C x y) (ZR (RectangleP (C zx zy) w h) _) = x >= zx && x <= zx + fromIntegral w && y >= zy && y <= zy + fromIntegral h
isWithinZone (C x y) (ZC (RectangleP (C zx zy) w h) _) = x >= zx && x <= zx + fromIntegral w && y >= zy && y <= zy + fromIntegral h
isWithinZone (C x y) (ZI (RectangleP (C zx zy) w h) _) = x >= zx && x <= zx + fromIntegral w && y >= zy && y <= zy + fromIntegral h
isWithinZone _ _ = False

-- Example usage of checkTouch
checkTouch :: Maybe (Int, Int) -> GameState -> Bool
checkTouch Nothing _ = False
checkTouch (Just (mouseX, mouseY)) _ =
  mouseX >= 1850 && mouseX <= 1850 + 100 && mouseY >= 140 && mouseY <= 140 + 100
