module Model.Ville where

import qualified Data.Map as M  -- Utilisez un alias pour Data.Map
import Model.Shapes
import Data.List as List
import Data.Maybe (isJust, maybeToList)
import qualified Data.Maybe as DM (mapMaybe)
import System.IO.Unsafe (unsafePerformIO)
import qualified Data.Set as Set
import Data.Ord (comparing)
import Data.PSQueue (PSQ, Binding(..))
import qualified Data.PQueue.Min as PSQ
import qualified Data.Set as Set

type Graph = M.Map ZonId [ZonId]

data Citoyen = Immigrant Coord (Int, Int, Int) Occupation CitId
    | Habitant Coord (Int, Int, Int) (BatId, Maybe BatId, Maybe BatId) Occupation CitId
    | Emigrant Coord Occupation CitId
    deriving (Show)

data Occupation = Travailler
                | Dormir
                | Shopping
                | Chill
                | Move Coord
                deriving (Show)

data Ville = Ville
    { viZones :: M.Map ZonId Zone
    , viCit :: M.Map CitId Citoyen
    }
    deriving (Show)

type VilleInvariant = Ville -> Bool
villeInvariant :: VilleInvariant
villeInvariant = prop_ville_sansCollision 

extraireRoutes :: Ville -> [ZonId]
extraireRoutes ville = [zid | (zid, zone) <- M.toList (viZones ville), isRoute zone]
  where
    isRoute (Route _) = True
    isRoute _ = False

-- Crée un graphe de la ville en connectant les zones adjacentes aux routes
createGraph :: Ville -> Graph
createGraph ville = M.fromList [(zid, getAdjacentRouteIds ville zid) | (zid, zone) <- M.toList (viZones ville), isRoute zone]
  where
    isRoute (Route _) = True
    isRoute _ = False

-- Retourne les ZonId adjacents à une zone donnée par son ZonId
getAdjacentRouteIds :: Ville -> ZonId -> [ZonId]
getAdjacentRouteIds ville zid = [zid1
                                | (zid1, zone1) <- M.toList (viZones ville)
                                , isRoute zone1
                                , zonesAdjacentes (viZones ville M.! zid) zone1
                                , zid1 /= zid]
  where
    isRoute (Route _) = True
    isRoute _ = False


isConnected :: Graph -> Bool
isConnected graph
    | M.null graph = True
    | otherwise = Set.size (reachableNodes (head $ M.keys graph) graph Set.empty) == M.size graph

reachableNodes :: ZonId -> Graph -> Set.Set ZonId -> Set.Set ZonId
reachableNodes node graph visited
    | Set.member node visited = visited
    | otherwise = List.foldr (\n v -> reachableNodes n graph v) (Set.insert node visited) (M.findWithDefault [] node graph)

prop_routes_connexes :: Ville -> Bool
prop_routes_connexes = isConnected . createGraph

prop_ville_sansCollision :: Ville -> Bool
prop_ville_sansCollision ville = prop_zones_dijoints ville && prop_zone_adjacent_route ville && prop_routes_connexes ville

-- Fonction pour afficher la ville
showVille :: Ville -> String
showVille ville = unlines $ map showZone (M.toList (viZones ville)) ++ lines (showCitoyens (viCit ville))
  where
    showZone (zid, zone) = "Zone ID: " ++ show zid ++ ", " ++ show zone

-- Fonction pour afficher les citoyens
showCitoyens :: M.Map CitId Citoyen -> String
showCitoyens citoyens = unlines $ map showCitoyen (M.toList citoyens)
  where
    showCitoyen (cid, citoyen) = "Citoyen ID: " ++ show cid ++ ", " ++ show citoyen


prop_zones_dijoints :: Ville -> Bool
prop_zones_dijoints ville = 
  Prelude.foldr (&&) True allComparisons
  where
    allComparisons = [not (zoneCollision zone1 zone2)
                     | (zid1, zone1) <- M.toList (viZones ville)
                     , (zid2, zone2) <- M.toList (viZones ville)
                     , zid1 /= zid2
                     ]

                     
prop_zone_adjacent_route :: Ville -> Bool
prop_zone_adjacent_route ville =
    Prelude.foldr (&&) True allComparisons
  where
    allComparisons = [besideRoad zone1 $ getAdjacent ville zone1
                     | (zid1, zone1) <- M.toList (viZones ville)
                     ]

contientRoute :: [Zone] -> Bool
contientRoute zones = any isRoute zones
  where
    isRoute (Route _) = True
    isRoute _ = False

besideRoad :: Zone -> [Zone] -> Bool
besideRoad (Route _) _ = True
besideRoad (Eau _) _ = True
besideRoad _ zonesList = contientRoute zonesList

getAdjacent :: Ville -> Zone -> [Zone]
getAdjacent ville zone = [zone1
                         | (_, zone1) <- M.toList (viZones ville)
                         , zonesAdjacentes zone zone1
                         ]


preConstruit :: Ville -> Zone -> ZonId -> Bool
preConstruit ville zone zonId = 
    let updatedVille = ville { viZones = M.insert zonId zone (viZones ville) }
    in  prop_ville_sansCollision updatedVille
        
construit :: Ville -> Zone -> ZonId -> Ville
construit ville zone zonId = Ville { viZones = M.insert zonId zone (viZones ville), viCit = viCit ville }

postConstruit :: Ville -> Zone -> ZonId -> Ville -> Bool
postConstruit villePre zone zonId villePost =
    villeInvariant villePost &&
    isJust (M.lookup zonId (viZones villePost))

getForm :: Batiment -> Forme
getForm (Cabane form _ _ _ _) = form
getForm (Atelier form _ _ _ _) = form
getForm (Epicerie form _ _ _ _) = form
getForm (Commissariat form _ _ _ _) = form
getForm (Maison form _ _ _ _) = form

-- Add a new zone to the city
addZone :: Ville -> Zone -> Ville
addZone ville zone = ville { viZones = M.insert (nextZonId ville) zone (viZones ville) }

addBatiment :: Batiment -> Ville -> ZonId -> Ville
addBatiment batiment ville zonId = ville { viZones = M.adjust (insertBatiment batiment) zonId (viZones ville) }
  where
    insertBatiment :: Batiment -> Zone -> Zone
    insertBatiment b (ZR form bs) = ZR form (b:bs)
    insertBatiment b (ZI form bs) = ZI form (b:bs)
    insertBatiment b (ZC form bs) = ZC form (b:bs)
    insertBatiment _ zone = zone  -- Ajouter seulement aux zones résidentielles, industrielles ou commerciales

-- Génère le prochain ID de zone
nextZonId :: Ville -> ZonId
nextZonId ville = ZonId (M.size (viZones ville) + 1)

-- Checks if a building form is within the given boundary of a zone
isWithin :: Forme -> Forme -> Bool
isWithin buildingForm zoneForm =
  let (minY1, maxY1, minX1, maxX1) = limites buildingForm
      (minY2, maxY2, minX2, maxX2) = limites zoneForm
  in (maxY1 <= maxY2 && minY1 >= minY2) && (maxX1 <= maxX2 && minX1 >= minX2)

-- Checks for overlapping of two forms
isOverlapping :: Forme -> Forme -> Bool
isOverlapping f1 f2 =
  let (minY1, maxY1, minX1, maxX1) = limites f1
      (minY2, maxY2, minX2, maxX2) = limites f2
  in not (maxY1 < minY2 || minY1 > maxY2 || maxX1 < minX2 || minX1 > maxX2)

-- Utility to check if a building can be added to a zone
canAddBuilding :: Batiment -> Zone -> Bool
canAddBuilding (Cabane form _ _ _ _) (ZR zoneForm buildings) =
    isWithin form zoneForm && not (any (isOverlapping form . getForm) buildings)
canAddBuilding _ _ = False  -- Simplify for other types, customize as necessary

creerImmigrant :: Coord -> (Int, Int, Int) -> Occupation -> CitId -> Citoyen
creerImmigrant coord etat occupation cid = Immigrant coord etat occupation cid

-- Transformer un immigrant en habitant
transformerImmigrantEnHabitant :: Citoyen -> BatId -> Maybe BatId -> Maybe BatId -> Citoyen
transformerImmigrantEnHabitant (Immigrant coord etat occupation cid) maisonId travailId magasinId = 
    Habitant coord etat (maisonId, travailId, magasinId) occupation cid
transformerImmigrantEnHabitant _ _ _ _ = error "Seuls les immigrants peuvent être transformés en habitants"

-- Mettre à jour l'occupation et la position des citoyens
updateCitizens :: Ville -> Ville
updateCitizens ville = ville { viCit = M.map (mettreAJourPosition ville) (viCit ville) }

-- Mettre à jour la position d'un citoyen
mettreAJourPosition :: Ville -> Citoyen -> Citoyen
mettreAJourPosition ville citoyen@(Habitant coord (argent, fatigue, faim) batiments occupation cid) =
  case occupation of
    Move dest ->
      let zidStart = getZoneIdAtCoord ville coord
          zidDest = getZoneIdAtCoord ville dest
      in case (zidStart, zidDest) of
           (Just start, Just goal) ->
             case aStar ville start goal of
               Just (nextZid:_) ->
                 let nextCoord = coordZone ville nextZid
                 in citoyen { citoyenCoord = nextCoord }
               _ -> citoyen
           _ -> citoyen
    _ -> citoyen
mettreAJourPosition _ citoyen = citoyen

-- Helper pour obtenir les coordonnées d'un citoyen
citoyenCoord :: Citoyen -> Coord
citoyenCoord (Immigrant coord _ _ _) = coord
citoyenCoord (Habitant coord _ _ _ _) = coord
citoyenCoord (Emigrant coord _ _) = coord

-- Helper pour définir les coordonnées d'un citoyen
setCitoyenCoord :: Citoyen -> Coord -> Citoyen
setCitoyenCoord (Immigrant _ etat occupation cid) newCoord = Immigrant newCoord etat occupation cid
setCitoyenCoord (Habitant _ etat batiments occupation cid) newCoord = Habitant newCoord etat batiments occupation cid
setCitoyenCoord (Emigrant _ occupation cid) newCoord = Emigrant newCoord occupation cid




-- Helper pour obtenir l'ID d'un citoyen
getCitId :: Citoyen -> CitId
getCitId (Immigrant _ _ _ cid) = cid
getCitId (Habitant _ _ _ _ cid) = cid
getCitId (Emigrant _ _ cid) = cid

getBatimentId :: Batiment -> BatId
getBatimentId (Cabane _ _ _ batId _) = batId
getBatimentId (Atelier _ _ _ batId _) = batId
getBatimentId (Epicerie _ _ _ batId _) = batId
getBatimentId (Commissariat _ _ _ batId _) = batId
getBatimentId (Maison _ _ _ batId _) = batId

-- Helper pour obtenir les coordonnées d'un bâtiment
coordBatiment :: Ville -> BatId -> Coord
coordBatiment ville batId = case DM.mapMaybe getCoord (concatMap batimentsInZone (M.elems (viZones ville))) of
                              [coord] -> coord
                              _ -> error "Batiment non trouvé"
  where
    getCoord :: Batiment -> Maybe Coord
    getCoord b | batId == getBatimentId b = Just (coordOf b)
               | otherwise = Nothing

    coordOf :: Batiment -> Coord
    coordOf (Cabane _ coord _ _ _) = coord
    coordOf (Atelier _ coord _ _ _) = coord
    coordOf (Epicerie _ coord _ _ _) = coord
    coordOf (Commissariat _ coord _ _ _) = coord
    coordOf (Maison _ coord _ _ _) = coord


    batimentsInZone :: Zone -> [Batiment]
    batimentsInZone (ZR _ batiments) = batiments
    batimentsInZone (ZI _ batiments) = batiments
    batimentsInZone (ZC _ batiments) = batiments
    batimentsInZone _ = []
  

-- Helper functions for A* algorithm
type Cost = Int
type Path = [ZonId]

aStar :: Ville -> ZonId -> ZonId -> Maybe Path
aStar ville start goal =
    let graph = createGraph ville
        heuristic a b = manhattanDistance (coordZone ville a) (coordZone ville b)
        manhattanDistance (C x1 y1) (C x2 y2) = abs (x1 - x2) + abs (y1 - y2)
    in search graph heuristic start goal

search :: Graph -> (ZonId -> ZonId -> Cost) -> ZonId -> ZonId -> Maybe Path
search graph heuristic start goal = go Set.empty (PSQ.singleton start 0) (PSQ.singleton start (0, [start]))
  where
    go _ _ cameFrom | PSQ.null cameFrom = Nothing
    go closed open cameFrom =
      let (current PSQ.:-> _) = PSQ.findMin open
      in if current == goal
         then Just $ reverse $ snd $ cameFrom PSQ.! current
         else
           let neighbors = graph M.! current
               newClosed = Set.insert current closed
               processNeighbor (cFrom, openQueue) neighbor =
                 let newCost = (fst $ PSQ.findWithDefault (maxBound, []) current cameFrom) + 1
                     oldCost = fst $ PSQ.findWithDefault (maxBound, []) neighbor cameFrom
                 in if Set.member neighbor newClosed || newCost >= oldCost
                    then (cFrom, openQueue)
                    else ( PSQ.insert neighbor (newCost, current : snd (cameFrom PSQ.! current)) cFrom
                         , PSQ.insert neighbor (newCost + heuristic neighbor goal) openQueue
                         )
               (newCameFrom, newOpen) = foldl processNeighbor (cameFrom, PSQ.deleteMin open) neighbors
           in go newClosed newOpen newCameFrom

coordZone :: Ville -> ZonId -> Coord
coordZone ville zid = case M.lookup zid (viZones ville) of
  Just (Route (RectangleP coord _ _)) -> coord
  _ -> error "Zone non trouvée ou non routière"
