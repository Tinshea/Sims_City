module Model.Shapes where

newtype ZonId = ZonId Int deriving (Eq, Ord, Show)
newtype BatId = BatId Int deriving (Eq, Ord, Show)
newtype CitId = CitId String deriving (Eq, Ord, Show)

data Coord = C {cx :: Int, cy :: Int} 
            deriving (Show, Eq)

data Forme = HSegment Coord Int
           | VSegment Coord Int
           | RectangleP Coord Int Int 
           deriving (Show, Eq)

data Zone = Eau Forme
          | Route Forme
          | ZR Forme [Batiment]
          | ZI Forme [Batiment]
          | ZC Forme [Batiment]
          | Admin Forme Batiment
          deriving (Show)

data Batiment = Cabane  Forme Coord ZonId BatId [CitId]
                | Atelier  Forme Coord ZonId BatId [CitId]
                | Epicerie  Forme Coord ZonId BatId [CitId]
                | Maison  Forme Coord ZonId BatId [CitId]
                | Commissariat  Forme Coord ZonId BatId [CitId]

instance Show Batiment where
  show (Cabane forme coord zonid batid citIds) = "Cabane " ++ show forme ++ " " ++ show coord ++ " " ++ show zonid ++ " " ++ show batid ++ " " ++ show citIds 
  show (Atelier forme coord zonid batid citIds) = "Atelier " ++ show forme ++ " " ++ show coord ++ " " ++ show zonid ++ " " ++ show batid ++ " " ++ show citIds
  show (Epicerie forme coord zonid batid citIds) = "Epicerie " ++ show forme ++ " " ++ show coord ++ " " ++ show zonid ++ " " ++ show batid ++ " " ++ show citIds
  show (Commissariat forme coord zonid batid citIds) = "Commissariat " ++ show forme ++ " " ++ show coord  ++ " " ++ show zonid ++ " " ++ show batid ++ " " ++ show citIds
  show (Maison forme coord zonid batid citIds) = "Maison " ++ show forme ++ " " ++ show coord ++ " " ++ show zonid ++ " " ++ show batid ++ " " ++ show citIds


instance Eq Zone where
  (Eau forme1) == (Eau forme2) = forme1 == forme2
  (Route forme1) == (Route forme2) = forme1 == forme2
  (ZR forme1 _) == (ZR forme2 _) = forme1 == forme2 
  (ZI forme1 _) == (ZI forme2 _) = forme1 == forme2
  (ZC forme1 _) == (ZC forme2 _) = forme1 == forme2
  (Admin forme1 _) == (Admin forme2 _) = forme1 == forme2
  _ == _ = False

zoneForme :: Zone -> Forme
zoneForme (Eau forme) = forme
zoneForme (Route forme) = forme
zoneForme (ZR forme _) = forme
zoneForme (ZI forme _) = forme
zoneForme (ZC forme _) = forme
zoneForme (Admin forme _) = forme

zonesDijoints :: Zone -> Zone -> Bool
zonesDijoints zone1 zone2 = not (collision (zoneForme zone1) (zoneForme zone2))

limites :: Forme -> (Int, Int, Int, Int)
limites (HSegment (C x y) l) = (y, y, x, x + l - 1)
limites (VSegment (C x y) l) = (y, y - l - 1, x, x)
limites (RectangleP (C x y) w h) = (y, y + h - 1, x, x + w - 1)

appartient :: Coord -> Forme -> Bool
appartient (C x y) forme = let (nord, sud, ouest, est) = limites forme
                           in y >= nord && y <= sud && x >= ouest && x <= est

adjacent :: Coord -> Forme -> Bool
adjacent (C x y) forme = let (nord, sud, ouest, est) = limites forme
                         in (y == nord + 1 && x >= ouest && x <= est) ||
                            (y == sud - 1 && x >= ouest && x <= est) ||
                            (x == ouest + 1 && y >= nord && y <= sud) ||
                            (x == est - 1 && y >= nord && y <= sud)

-- Fonction pour déterminer si deux formes sont adjacentes avec une tolérance 
formesAdjacentes :: Forme -> Forme -> Bool
formesAdjacentes forme1 forme2 =
    let (minY1, maxY1, minX1, maxX1) = limites forme1
        (minY2, maxY2, minX2, maxX2) = limites forme2
        tolerance = 25
    in ((maxY1 + tolerance >= minY2 && maxY1 <= minY2) || (minY1 >= maxY2 && minY1 <= maxY2 + tolerance)) 
        && (minX1 <= maxX2 && maxX1 >= minX2)
        || ((maxX1 + tolerance >= minX2 && maxX1 <= minX2) || (minX1 >= maxX2 && minX1 <= maxX2 + tolerance)) 
        && (minY1 <= maxY2 && maxY1 >= minY2)


-- Fonction pour vérifier si deux zones sont adjacentes
zonesAdjacentes :: Zone -> Zone -> Bool
zonesAdjacentes zone1 zone2 = formesAdjacentes (zoneForme zone1) (zoneForme zone2)

zoneCollision :: Zone -> Zone -> Bool
zoneCollision zone1 zone2 = collision (zoneForme zone1) (zoneForme zone2)


-- c'est pas exact ça 
collision :: Forme -> Forme -> Bool
collision forme1 forme2 = 
  let (nord1, sud1, ouest1, est1) = limites forme1
      (nord2, sud2, ouest2, est2) = limites forme2
  in not ((est1 < ouest2) || (ouest1 > est2) || (sud1 < nord2) || (nord1 > sud2))