module VilleSpec where

import Model.Ville
import Test.Hspec
import Model.Shapes
import qualified Data.Map as Map
import ShapesSpec (makeAdjacent)

-- makeExtraireRoutes = do
--     describe "extraireRoutes" $ do
--       it "returns the correct routes" $ do
--         let ville = Ville (Map.fromList [(ZonId 1, Route (RectangleP (C 0 0) 10 20)), (ZonId 2, Eau (RectangleP (C 0 0) 10 20)), (ZonId 4, Route (RectangleP (C 0 0) 10 20))]) Map.empty
--         extraireRoutes ville `shouldBe` [ZonId 1, ZonId 4]

makeContientRoute = do
    describe "contientRoute" $ do
      it "returns True if a Ville contains a Route" $ do
        let zones = [Route (RectangleP (C 0 0) 10 20), Eau (RectangleP (C 0 0) 10 20)]
        contientRoute zones `shouldBe` True
      it "returns False if a Ville does not contain a Route" $ do
        let zones = [Eau (RectangleP (C 0 0) 10 20), ZR (RectangleP (C 0 0) 10 20) []]
        contientRoute zones `shouldBe` False

makeBesideRoad = do
    describe "besideRoad" $ do
      it "returns True if a Zone is beside a Route" $ do
        let zone = Route (RectangleP (C 0 0) 10 20)
            zonesList = [Route (RectangleP (C 0 0) 10 20), Eau (RectangleP (C 0 0) 10 20)]
        besideRoad zone zonesList `shouldBe` True
      it "returns False if a Zone is not beside a Route" $ do
        let zone = ZR (RectangleP (C 0 0) 10 20) []
            zonesList = [Eau (RectangleP (C 0 0) 10 20), ZR (RectangleP (C 0 0) 10 20) []]
        besideRoad zone zonesList `shouldBe` False

makeGetAdjacent = do
    describe "getAdjacent" $ do
      it "returns the correct adjacent Zones" $ do
        let ville = Ville (Map.fromList [(ZonId 1, Route (RectangleP (C 0 0) 10 20)), (ZonId 2, Eau (RectangleP (C 10 0) 10 20)), (ZonId 4, Route (RectangleP (C 0 0) 10 20))]) Map.empty
            zone = Route (RectangleP (C 0 0) 10 10)
        getAdjacent ville zone `shouldBe` [Eau (RectangleP (C 10 0) 10 20)]
      it "returns the correct adjacent Zones" $ do
        let ville = Ville (Map.fromList [(ZonId 1, Route (RectangleP (C 0 0) 10 20)), (ZonId 2, Eau (RectangleP (C 0 0) 10 20)), (ZonId 4, Route (RectangleP (C 0 0) 10 20))]) Map.empty
            zone = Route (RectangleP (C 0 0) 10 10)
        getAdjacent ville zone `shouldBe` []

makePropRoutesConnexes = do
    describe "propRoutesConnexes" $ do
      it "checks if streets are connexes" $ do
        let ville = Ville (Map.fromList [(ZonId 1, Route (RectangleP (C 0 0) 10 1)), (ZonId 2, Route (RectangleP (C 10 0) 10 1)), (ZonId 3, Route (RectangleP (C 20 0) 1 10)), (ZonId 4, Route (RectangleP (C 20 10) 1 10))]) Map.empty
        prop_routes_connexes ville `shouldBe` True
      it "checks if streets are connexes" $ do
        let ville = Ville (Map.fromList [(ZonId 1, Route (RectangleP (C 0 0) 10 0)), (ZonId 2, Route (RectangleP (C 20 0) 0 10))]) Map.empty
        prop_routes_connexes ville `shouldBe` False

makeAdjacent2 = do
    describe "getAdjacent2 with ZonId" $ do
      it "checks getAjacent2" $ do
        let ville = Ville (Map.fromList [(ZonId 1, Route (RectangleP (C 0 0) 10 1)), (ZonId 2, Route (RectangleP (C 10 0) 10 1)), (ZonId 3, Route (RectangleP (C 10 10) 10 1)), (ZonId 4, Route (RectangleP (C 20 10) 10 1))]) Map.empty
        getAdjacent2 ville (ZonId 1) `shouldBe` [ZonId 2]
        
makeGraph = do
    describe "createGraph" $ do
      it "checks if the constructed graph is correct" $ do
        let ville = Ville (Map.fromList [(ZonId 1, Route (RectangleP (C 0 0) 10 1)), (ZonId 2, Route (RectangleP (C 10 0) 1 10)), (ZonId 3, Route (RectangleP (C 10 10) 10 1)), (ZonId 4, Route (RectangleP (C 20 10) 10 1))]) Map.empty
            graph = Map.fromList [(ZonId 1, [ZonId 2]), (ZonId 2, [ZonId 1, ZonId 3]), (ZonId 3, [ZonId 2, ZonId 4]), (ZonId 4, [ZonId 3])]
        createGraph ville `shouldBe` graph

makeIsWithin = do
  describe "isWithin" $ do
    it "returns True if a building form is within the boundary of a zone" $ do
      let buildingForm = RectangleP (C 0 0) 5 5
          zoneForm = RectangleP (C 0 0) 10 10
      isWithin buildingForm zoneForm `shouldBe` True
    it "returns True if a building form is within the boundary of a zone 2" $ do
      let buildingForm = RectangleP (C 3 3) 5 5
          zoneForm = RectangleP (C 0 0) 10 10
      isWithin buildingForm zoneForm `shouldBe` True
    it "returns False if a building form is not within the boundary of a zone" $ do
      let buildingForm = RectangleP (C 0 0) 15 15
          zoneForm = RectangleP (C 0 0) 10 10
      isWithin buildingForm zoneForm `shouldBe` False

makeIsOverlapping = do
  describe "isOverlapping" $ do
    it "returns True if two forms are overlapping" $ do
      let f1 = RectangleP (C 0 0) 10 10
          f2 = RectangleP (C 5 5) 10 10
      isOverlapping f1 f2 `shouldBe` True
    it "returns False if two forms are not overlapping" $ do
      let f1 = RectangleP (C 0 0) 10 10
          f2 = RectangleP (C 15 15) 10 10
      isOverlapping f1 f2 `shouldBe` False
         
villeSpec = do 
    describe "Ville Tests" $ do
        makeExtraireRoutes
        makeContientRoute
        makeBesideRoad
        makeGetAdjacent
        makePropRoutesConnexes
        makeAdjacent2
        makeGraph
        makeIsWithin
        makeIsOverlapping