module ShapesSpec where

import Model.Shapes
import Test.Hspec

makeZoneForme = do
    describe "zoneForme" $ do
      it "returns the correct Forme for each Zone" $ do
        let zone1 = Eau (RectangleP (C 0 0) 10 20)
        zoneForme zone1 `shouldBe` RectangleP (C 0 0) 10 20
        let zone2 = Route (RectangleP (C 0 0) 10 20)
        zoneForme zone2 `shouldBe` RectangleP (C 0 0) 10 20
        let zone3 = ZR (RectangleP (C 0 0) 10 20) []
        zoneForme zone3 `shouldBe` RectangleP (C 0 0) 10 20
        let zone4 = ZI (RectangleP (C 0 0) 10 20) []
        zoneForme zone4 `shouldBe` RectangleP (C 0 0) 10 20
        let zone5 = ZC (RectangleP (C 0 0) 10 20) []
        zoneForme zone5 `shouldBe` RectangleP (C 0 0) 10 20
        let zone6 = Admin (RectangleP (C 0 0) 10 20) (Cabane (RectangleP (C 0 0) 10 20) (C 0 0) 10 [])
        zoneForme zone6 `shouldBe` RectangleP (C 0 0) 10 20

makeLimites = do
    describe "limites" $ do
      it "returns the correct limits for a Forme" $ do
        let forme1 = HSegment (C 0 0) 10
        limites forme1 `shouldBe` (0, 0, 0, 9)
        let forme2 = VSegment (C 0 0) 10
        limites forme2 `shouldBe` (0, -11, 0, 0)
        let forme3 = RectangleP (C 0 0) 10 20
        limites forme3 `shouldBe` (0, 19, 0, 9)

makeAppartient = do
    describe "appartient" $ do
      it "returns True if a Coord is in a Forme" $ do
        let coord = C 0 0
            forme = RectangleP (C 0 0) 10 10
        appartient coord forme `shouldBe` True
      it "returns False if a Coord is not in a Forme" $ do
        let coord = C 11 11
            forme = RectangleP (C 0 0) 10 10
        appartient coord forme `shouldBe` False

makeAdjacent = do
    describe "adjacent" $ do
      it "returns True if a Coord is adjacent to a Forme" $ do
        let coord = C 0 1
            forme = RectangleP (C 0 0) 10 10
        adjacent coord forme `shouldBe` True
      it "returns False if a Coord is not adjacent to a Forme" $ do
        let coord = C 0 2
            forme = RectangleP (C 0 0) 10 10
        adjacent coord forme `shouldBe` False

makeFormesAdjacentes = do
    describe "formesAdjacentes" $ do
      it "returns True if two rectangles are adjacent" $ do
        let forme1 = RectangleP (C 0 0) 10 10
            forme2 = RectangleP (C 10 0) 10 10
        formesAdjacentes forme1 forme2 `shouldBe` True
      it "returns False if two rectangles are not adjacent" $ do
        let forme1 = RectangleP (C 0 0) 5 5
            forme2 = RectangleP (C 11 0) 5 5
        formesAdjacentes forme1 forme2 `shouldBe` False

makeZonesAdjacentes = do
    describe "zonesAdjacentes" $ do
      it "returns True if two zones with adjacent forms are given" $ do
        let zone1 = Route (RectangleP (C 0 0) 10 10)
            zone2 = Route (RectangleP (C 10 0) 10 10)
        zonesAdjacentes zone1 zone2 `shouldBe` True
      it "returns False if two zones with non-adjacent forms are given" $ do
        let zone1 = Route (RectangleP (C 0 0) 10 10)
            zone2 = Route (RectangleP (C 12 0) 10 10)
        zonesAdjacentes zone1 zone2 `shouldBe` False
      it "test supp" $ do
        let zone1 = Route (RectangleP (C 0 0) 10 1)
            zone2 = Route (RectangleP (C 10 0) 10 1)
        zonesAdjacentes zone1 zone2 `shouldBe` True

makeCollision = do
    describe "collision" $ do
      it "returns True if two rectangles collide" $ do
        let forme1 = RectangleP (C 0 0) 10 10
            forme2 = RectangleP (C 5 5) 10 10
        collision forme1 forme2 `shouldBe` True
      it "returns False if two rectangles do not collide" $ do
        let forme1 = RectangleP (C 0 0) 10 10
            forme2 = RectangleP (C 10 0) 10 10
        collision forme1 forme2 `shouldBe` False
        
shapesSpec = do 
  describe "Shapes Tests" $ do
    makeZoneForme
    makeLimites
    makeAppartient
    makeAdjacent
    makeFormesAdjacentes
    makeZonesAdjacentes
    makeCollision
